"""
Question 1: Draw an environment diagram that reflects how the following
program will execute up to (but not including) the print(num) statement:
"""

def foo(x):
   return x**3

num = foo(2)
print(num)

# see slides for environment diagram rules









# see slides for deriv context

"""
Question 2: Fill in the body of the deriv function, as well as the blanks in
the comments below.
"""

def deriv(f, dx=0.001):
    """
    Given a function f of one variable (which takes a float value
    and returns a float value)

    Returns a function that approximates the derivative df/dx.

    Optional parameter dx > 0 is the width of the approximation
    """



dfoo = deriv(foo) # => function approximately equal to ________

num = dfoo(2)  # approximately equal to ________
# print(num)




"""
dfoo is an example of a "closure": a function object and its enclosing frame
- this is how dfoo has access to the function it is the derivative of


deriv is a "higher-order" function:
- meaning that it operates on functions -- it takes a function as an argument
and/or returns a function as its result (in this case deriv does both!)

what are some of the higher-order functions in image processing 2?
"""



"""
Question 3: Fill in the blanks in the code below to compare the results of
our derivative approximations with the actual expected derivative value.
"""


dfoo = deriv(foo) # approximately 3x^2
ddfoo = deriv(dfoo) # approximately 6x

def compare(f, g, x_values):
    for x in x_values:
        print(f'{x=} {f(x)=} {g(x)=}')  # what does f'{x=} ... ' do?


# what type of object should g be?
#compare(dfoo, # YOUR CODE HERE , range(-10, 10))

#compare(ddfoo, # YOUR CODE HERE, range(-10, 10))




"""
Note about lambda expressions -- what steps of the "function definition" rule
does it use, and what does it skip?
"""



"""
Question 4: Fill in the missing code for nth_derivative
"""

def nth_derivative(f, n):
    """
    Given a function f of one variable (takes a float value and
    returns a float value)

    returns a function that approximates the nth derivative of f.
    """






mystery = nth_derivative(foo, 0) # what is this equivalent to?
# print(mystery(2))
# print(nth_derivative(deriv, 2)(2)) # what is this equivalent to?
